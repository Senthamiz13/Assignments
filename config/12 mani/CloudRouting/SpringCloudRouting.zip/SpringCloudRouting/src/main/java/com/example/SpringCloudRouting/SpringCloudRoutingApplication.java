package com.example.SpringCloudRouting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudRoutingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudRoutingApplication.class, args);
	}

}
