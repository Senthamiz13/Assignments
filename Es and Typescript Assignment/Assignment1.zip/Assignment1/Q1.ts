const pi = 3.14;
console.log(pi);

pi = 3.1415; // throws  invalid assignment to const 'pi'

console.log(pi);
