let laptopModel = 'Hp Pavillion';
let deskNo = 101;
let name1 = 'Sen';

///////////using literal
console.log(`Customer Name: ${name1},
with Desktop Number: ${deskNo},
Laptop Model: ${laptopModel}`);
