package springREST.Assignment.REST.Q1;

import org.springframework.stereotype.Service;

@Service
public class HelloWorldService {
	
	public String print() {
		return "Hello World";
		
	}

}